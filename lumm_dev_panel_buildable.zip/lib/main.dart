import 'package:flutter/material.dart';

void main() => runApp(const DeveloperPanelApp());

class DeveloperPanelApp extends StatelessWidget {
  const DeveloperPanelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LummX Developer',
      theme: ThemeData.dark(useMaterial3: true),
      home: const DeveloperHomePage(),
    );
  }
}

class DeveloperHomePage extends StatefulWidget {
  const DeveloperHomePage({super.key});

  @override
  State<DeveloperHomePage> createState() => _DeveloperHomePageState();
}

class _DeveloperHomePageState extends State<DeveloperHomePage> {
  final users = <Map<String, String>>[];
  final username = TextEditingController();
  String role = 'user';

  @override
  void dispose() {
    username.dispose();
    super.dispose();
  }

  void addUser() {
    final name = username.text.trim();
    if (name.isEmpty) return;
    setState(() {
      users.add({'username': name, 'role': role});
      username.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Akun ditambahkan di sesi lokal.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('LummX Developer Panel')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Account Manager', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Template lokal. Hubungkan ke backend resmi milikmu sebelum dipakai bersama aplikasi lain.'),
                  const SizedBox(height: 16),
                  TextField(
                    controller: username,
                    decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: role,
                    decoration: const InputDecoration(labelText: 'Role', border: OutlineInputBorder()),
                    items: const ['user', 'staf', 'reseller', 'developer'].map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
                    onChanged: (value) => setState(() => role = value ?? 'user'),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(width: double.infinity, child: FilledButton(onPressed: addUser, child: const Text('Tambah Akun'))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Akun pada sesi ini', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (users.isEmpty) const Text('Belum ada akun.'),
          ...users.asMap().entries.map((entry) {
            final user = entry.value;
            return Card(
              child: ListTile(
                leading: const Icon(Icons.person),
                title: Text(user['username']!),
                subtitle: Text('Role: ${user['role']}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => setState(() => users.removeAt(entry.key)),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
