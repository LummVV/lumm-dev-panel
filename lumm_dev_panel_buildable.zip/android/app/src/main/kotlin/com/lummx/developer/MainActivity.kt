package com.lummx.developer
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
