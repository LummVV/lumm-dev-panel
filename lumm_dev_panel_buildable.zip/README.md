# LummX Developer Panel

Template Flutter untuk manajemen akun secara lokal.

## Build

```bash
flutter pub get
flutter build apk --release
```

## Catatan

Data masih tersimpan di memori aplikasi dan belum terhubung ke backend.
Untuk penggunaan nyata, tambahkan API autentikasi dan endpoint backend yang kamu miliki serta punya izin untuk kelola.
